using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Model
{
    public class CustomerModel
    {
         public int c_tokenid { get; set; }

        public  string? c_type { get; set; }

        public  string? c_name { get; set; }

        public  double c_mobile { get; set; }

        public  int c_status { get; set; }
    }
}