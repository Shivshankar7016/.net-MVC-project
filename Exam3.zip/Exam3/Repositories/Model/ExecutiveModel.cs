using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Model
{
    public class ExecutiveModel
    {
        public int c_loginid { get; set; }

        public  string? c_password { get; set; }

        public  string? c_type { get; set; }

    }
}