using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repositories.Model;

namespace Repositories.Interface
{
    public interface ICustomer
    {
        int AddToken(CustomerModel t);
        // int AddToken(CustomerModel token);
        List<CustomerModel> GetAll();
    }
}