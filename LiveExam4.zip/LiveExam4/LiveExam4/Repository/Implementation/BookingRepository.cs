using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repository.Models;
using Npgsql;
using Microsoft.Extensions.Configuration;
using System.Data;
using Repository.Interface;
using Microsoft.AspNetCore.Http;

namespace Repository.Implementation
{
    public class BookingRepository : IBookingRepository
    {
        private readonly string _con;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public BookingRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
            _httpContextAccessor = httpContextAccessor;
        }

       
    //     this is method for user can book for bus and from this current stock is also deduct from t_tripmaster118 table which is added by admin
        public bool AddBooking(TripModel tripModel)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                try
                {
                    conn.Open();
                    var uid = _httpContextAccessor.HttpContext.Session.GetInt32("UserId");

                    if (uid.HasValue)
                    {
                        // Begin a transaction to ensure atomicity
                        using (var transaction = conn.BeginTransaction())
                        {
                            try
                            {
                                var updateCmd = new NpgsqlCommand("UPDATE t_tripmaster118 SET c_cstock = c_cstock - @c_qty WHERE c_trip = @c_trip AND c_cstock >= @c_qty", conn, transaction);
                                updateCmd.Parameters.AddWithValue("@c_qty", tripModel.c_qty);
                                updateCmd.Parameters.AddWithValue("@c_trip", tripModel.c_trip);

                                if (updateCmd.ExecuteNonQuery() == 0)
                                {
                                    // If no rows were updated (probably because the quantity exceeds the available stock), rollback the transaction and return false
                                    transaction.Rollback();
                                    Console.WriteLine("Insufficient stock.");
                                    return false;
                                }

                                // Insert the booking details into the t_tripbooking118 table
                                var insertCmd = new NpgsqlCommand("INSERT INTO t_tripbooking118 (c_uid, c_trip, c_tdate, c_price, c_cstock, c_qty, c_cost, c_status) VALUES (@c_uid, @c_trip, @c_tdate, @c_price, @c_cstock, @c_qty, @c_cost, 0)", conn, transaction);
                                insertCmd.Parameters.AddWithValue("@c_uid", uid.Value);
                                insertCmd.Parameters.AddWithValue("@c_trip", tripModel.c_trip);
                                insertCmd.Parameters.AddWithValue("@c_tdate", tripModel.c_tdate);
                                insertCmd.Parameters.AddWithValue("@c_price", tripModel.c_price);
                                insertCmd.Parameters.AddWithValue("@c_cstock", tripModel.c_cstock);
                                insertCmd.Parameters.AddWithValue("@c_qty", tripModel.c_qty);
                                insertCmd.Parameters.AddWithValue("@c_cost", tripModel.c_tcost);

                                insertCmd.ExecuteNonQuery();

                                // Commit the transaction if all operations succeed
                                transaction.Commit();

                                return true;
                            }
                            catch (NpgsqlException ex)
                            {
                                // Rollback the transaction if any exception occurs
                                transaction.Rollback();
                                Console.WriteLine("Database error: " + ex.Message);
                                return false;
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("UserId session value is null.");
                        return false;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
                finally
                {
                    conn.Close();
                }
            }
        }

//  Fetch All bus details
        public List<BookModel> FetchBooking()
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                var trips = new List<BookModel>();

                try
                {
                    conn.Open();
                    using var command = new NpgsqlCommand("select * from t_tripbooking118", conn);
                    command.CommandType = CommandType.Text;

                    using var reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        var trip = new BookModel
                        {
                            c_bid = Convert.ToInt32(reader["c_bid"]),
                            c_tdate = Convert.ToDateTime(reader["c_tdate"]),
                            c_price = Convert.ToDouble(reader["c_price"]),
                            c_qty = Convert.ToInt32(reader["c_qty"]),
                            c_tcost = Convert.ToDouble(reader["c_cost"]),
                            c_status = Convert.ToInt32(reader["c_status"]),
                            c_trip = reader["c_trip"].ToString()
                        };
                        trips.Add(trip);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                return trips;
            }
        }

//  This is method for getting trip name (use in dropdown list)
        public List<TripModel> fetchTrip()
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                var trips = new List<TripModel>();
                try
                {
                    conn.Open();
                    var cmd = new NpgsqlCommand("SELECT c_trip FROM t_tripmaster118", conn);
                    var dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        var trip = new TripModel()
                        {
                            c_trip = dr["c_trip"].ToString(),
                        };
                        trips.Add(trip);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                return trips;
            }
        }


// This is method where we select in droplist when we select trip all releted details shown  on the screen
        public TripModel GetTripDetails(string trip)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                try
                {
                    conn.Open();

                    using var command = new NpgsqlCommand("SELECT * FROM t_tripmaster118 WHERE c_trip = @trip", conn);
                    command.Parameters.AddWithValue("@trip", trip);

                    using var reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        var tripDetails = new TripModel
                        {
                            c_trip = reader["c_trip"].ToString(),
                            c_price = Convert.ToInt32(reader["c_price"]),
                            c_cstock = Convert.ToInt32(reader["c_cstock"]),
                        };

                        return tripDetails;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
                return null;
            }
        }

//  User can cancle the booking ticket if booking date is future date
        public void CancelBooking(int id)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_con))
            {
                try
                {
                    conn.Open();

                    // First, retrieve the trip date using the provided booking ID
                    using var selectCommand = new NpgsqlCommand("SELECT c_tdate FROM t_tripbooking118 WHERE c_bid = @c_id", conn);
                    selectCommand.Parameters.AddWithValue("@c_id", id);
                    selectCommand.CommandType = CommandType.Text;

                    // Execute the select command to get the trip date
                    var tripDate = (DateTime)selectCommand.ExecuteScalar();

                    Console.WriteLine("Trip Date Retrieved from Database: " + tripDate); // Log the retrieved trip date

                    // Validate if trip date is greater than today's date
                    if (tripDate.Date > DateTime.Today)
                    {
                        // Update the booking status if trip date is valid
                        using var updateCommand = new NpgsqlCommand("UPDATE t_tripbooking118 SET c_status = 1 WHERE c_bid = @c_id", conn);
                        updateCommand.Parameters.AddWithValue("@c_id", id);
                        updateCommand.CommandType = CommandType.Text;

                        updateCommand.ExecuteNonQuery();
                        Console.WriteLine("Booking canceled successfully.");
                    }
                    else
                    {
                        Console.WriteLine("Cannot cancel booking. Trip date should be greater than today's date.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error canceling booking: " + ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
        }



    }
}