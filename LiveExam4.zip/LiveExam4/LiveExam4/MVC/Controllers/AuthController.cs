using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repository.Models;
using Repository.Interface;
using Repository.Implementation;

namespace MVC.Controllers
{
    // [Route("[controller]")]
    public class AuthController : Controller
    {
        private readonly ILogger<AuthController> _logger;
        private readonly IUserRepository _userRepository;

        public AuthController(ILogger<AuthController> logger, IUserRepository userRepository)
        {
            _logger = logger;
            _userRepository = userRepository;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }
        [HttpGet]
        public IActionResult AdminDashboard()
        {
            return View();
        }
        [HttpGet]
        public IActionResult History()
        {
            var History=_userRepository.History();
            return View(History);
        }
        [HttpPost]
        public IActionResult Login(AuthModel authModel)
        {
            var user = _userRepository.Login(authModel);
            if (user != null)
            {
                if (user.c_status == 1)
                {
                    return RedirectToAction("AdminDashboard");
                }
                else
                {
                    return RedirectToAction("UserDashboard", "User");
                }
            }
            else
            {
                return View();
            }
        }
        [HttpGet]
        public IActionResult AddTrip()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddTrip(TripModel tripModel)
        {
            _userRepository.AddTrip(tripModel);
            return View();
        }

        [HttpGet]
        public IActionResult DisplayTrip()
        {
            var trip = _userRepository.FetchAll();
            return View(trip);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            _userRepository.Delete(id);
            return RedirectToAction("DisplayTrip");
        }

        [HttpGet]
        public IActionResult UpdateTrip(int id)
        {
            var tripone = _userRepository.Show(id);
            return View(tripone);
        }
        [HttpPost]
        public IActionResult UpdateTrip(TripModel tripModel, int id)
        {
            _userRepository.Update(tripModel, id);
            return RedirectToAction("DisplayTrip");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}