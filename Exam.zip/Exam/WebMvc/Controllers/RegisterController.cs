using Microsoft.AspNetCore.Mvc;
using WebMvc.Models;
using WebMvc.Repositories;
using System;

namespace WebMvc.Controllers
{
    public class RegisterController : Controller
    {
        private readonly IUserRepositories _iuserRepositories;

        public RegisterController(IUserRepositories iuserRepositories)
        {
            _iuserRepositories = iuserRepositories;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(RegisterModel r)
        {
            if (ModelState.IsValid)
            {
                bool register = _iuserRepositories.RegistrationRecord(r);
                if(register)
                {
                    return RedirectToAction("Login");
                }
                else
                {
                    ModelState.AddModelError("c_email","Email already exist");
                }
                
            }
            return View(r);
        }

        [HttpPost]
        public IActionResult Login(RegisterModel model)
        {
                var user = _iuserRepositories.Login(model);

                if (user != null)
                {
                    if (user.c_status == false)
                    {
                        // User dashboard
                        return RedirectToAction("UserDashboard", "Dashboard");
                    }
                    else
                    {
                        // Admin dashboard
                        return RedirectToAction("AdminDashboard", "Dashboard");
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "Invalid email or password.";
                    return View(model);

                }
        }
       
    }
}
