using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace WebMvc.Models
{
    public class CategoryModel
    {
         public int c_categoryid { get; set; }

         [Required(ErrorMessage = "Category Name is required")]
    public string? c_categoryname { get; set; }
    }
}