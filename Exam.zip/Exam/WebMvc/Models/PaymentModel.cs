using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebMvc.Models
{
    public class PaymentModel
    {
        public int c_purchaseid { get; set; }
        public string? c_itemname { get; set; }
        public int c_itemcost { get; set; }
        public int c_qty { get; set; }
        public int c_totalcost { get; set; }

        public int c_id { get; set; }

    }
}