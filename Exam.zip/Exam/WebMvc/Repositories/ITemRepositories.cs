using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Npgsql;
using NpgsqlTypes;
using WebMvc.Models;

namespace WebMvc.Repositories
{
    public class ITemRepositories : CommanRepositories, IITemRepositories
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        private readonly IWebHostEnvironment _webHostEnvironment;

        public ITemRepositories(IHttpContextAccessor httpContextAccessor, IWebHostEnvironment webHostEnvironment)
        {
            _httpContextAccessor = httpContextAccessor;
            _webHostEnvironment = webHostEnvironment;
        }
        public List<CategoryModel> FetchAllItemRecord()
        {
            List<CategoryModel> tasks = new List<CategoryModel>();

            try
            {
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("SELECT c_categoryid, c_categoryname FROM public.t_category118", conn);
                using NpgsqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    CategoryModel task = new CategoryModel
                    {
                        c_categoryid = Convert.ToInt32(reader["c_categoryid"]),
                        c_categoryname = Convert.ToString(reader["c_categoryname"])
                    };
                    tasks.Add(task);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
            finally
            {
                conn.Close();
            }

            return tasks;
        }

        public void Categoryfill(CategoryModel t)
        {
            try
            {
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO public.t_category118 values(DEFAULT,@c_categoryname)", conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@c_categoryname", t.c_categoryname);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error show" + e.Message);
            }
            finally
            {
                conn.Close();
            }
        }
        public void insertAdmin(ItemModel t)
        {
            try
            {
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO public.t_item118 (c_itemname, c_categoryid, c_itemimage, c_itemcost, c_initialstock, c_availablestock) VALUES (@c_itemname, @c_categoryid, @c_itemimage, @c_itemcost, @c_initialstock, @c_availablestock)", conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@c_itemname", t.c_itemname);
                cmd.Parameters.AddWithValue("@c_categoryid", t.c_categoryid);
                cmd.Parameters.AddWithValue("@c_itemimage", t.c_itemimage);
                cmd.Parameters.AddWithValue("@c_itemcost", t.c_itemcost);
                cmd.Parameters.AddWithValue("@c_initialstock", t.c_initialstock);
                cmd.Parameters.AddWithValue("@c_availablestock", t.c_availablestock);
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        public List<ItemModel> FetchAllItems()
        {
            var items = new List<ItemModel>();
            try
            {
                conn.Open();
                using var cmd = new NpgsqlCommand("SELECT i.c_itemid, i.c_itemname, i.c_categoryid, i.c_itemimage, i.c_itemcost, i.c_initialstock, i.c_availablestock, c.c_categoryname " +
                                                  "FROM public.t_item118 i " +
                                                  "INNER JOIN public.t_category118 c ON i.c_categoryid = c.c_categoryid", conn);
                cmd.CommandType = CommandType.Text;
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    var item = new ItemModel
                    {
                        c_itemid = Convert.ToInt32(reader["c_itemid"]),
                        c_itemname = reader["c_itemname"].ToString(),
                        c_categoryid = Convert.ToInt32(reader["c_categoryid"]),
                        c_itemimage = reader["c_itemimage"].ToString(),
                        c_itemcost = Convert.ToInt32(reader["c_itemcost"]),
                        c_initialstock = Convert.ToInt32(reader["c_initialstock"]),
                        c_availablestock = Convert.ToInt32(reader["c_availablestock"]),
                        // Add category name fetched from the join
                        c_categoryname = reader["c_categoryname"].ToString()
                    };
                    items.Add(item);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error: {e.Message}");
            }
            finally
            {
                conn.Close();
            }
            return items;
        }

        public ItemModel FetchByID(int id)
        {
            ItemModel item = null;
            try
            {
                conn.Open();
                using var cmd = new NpgsqlCommand("SELECT * FROM t_item118 WHERE c_itemid = @id", conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@id", id);
                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    item = new ItemModel
                    {
                        c_itemid = Convert.ToInt32(reader["c_itemid"]),
                        c_itemname = reader["c_itemname"].ToString(),
                        c_categoryid = Convert.ToInt32(reader["c_categoryid"]),
                        c_itemimage = reader["c_itemimage"].ToString(),
                        c_itemcost = Convert.ToInt32(reader["c_itemcost"]),
                        c_initialstock = Convert.ToInt32(reader["c_initialstock"]),
                        c_availablestock = Convert.ToInt32(reader["c_availablestock"])
                    };
                }

            }
            catch (Exception e)
            {
                Console.WriteLine("Exception occurred while fetching record", e.Message);
            }
            finally
            {
                conn.Close();
            }
            return item;
        }

        public void UpdateItem(ItemModel item)
        {
            try
            {
                conn.Open();
                using var cmd = new NpgsqlCommand(@"UPDATE t_item118 SET c_itemname = @ItemName,
                 c_categoryid = @CategoryId, c_itemimage = @ItemImage, c_itemcost = @ItemCost,
                  c_initialstock = @InitialStock, c_availablestock = @AvailableStock WHERE c_itemid = @ItemId", conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ItemName", item.c_itemname);
                cmd.Parameters.AddWithValue("@CategoryId", item.c_categoryid);
                cmd.Parameters.AddWithValue("@ItemImage", item.c_itemimage);
                cmd.Parameters.AddWithValue("@ItemCost", item.c_itemcost);
                cmd.Parameters.AddWithValue("@InitialStock", item.c_initialstock);
                cmd.Parameters.AddWithValue("@AvailableStock", item.c_availablestock);
                cmd.Parameters.AddWithValue("@ItemId", item.c_itemid);

                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine($"An error occurred while updating the record: {e.Message}");
                // Log the exception or handle it appropriately
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteRecord(int id)
        {
            try
            {
                conn.Open();
                using var cmd = new NpgsqlCommand("DELETE FROM public.t_item118 WHERE c_itemid = @id", conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine($"An error occurred while deleting the record: {e.Message}");
            }
            finally
            {
                conn.Close();
            }
        }
         public void DeletePurchaseRecord(int id)
        {
            try
            {
                conn.Open();
                using var cmd = new NpgsqlCommand("DELETE FROM public.t_payment118 WHERE c_purchaseid = @id", conn);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine($"An error occurred while deleting the record: {e.Message}");
            }
            finally
            {
                conn.Close();
            }
        }

        public ItemModel ShowItem(int id)
        {
            conn.Open();

            using var command = new NpgsqlCommand("SELECT i.c_itemid, i.c_itemname, i.c_categoryid, i.c_itemimage, i.c_itemcost, i.c_initialstock, i.c_availablestock, c.c_categoryname " +
                                                  "FROM t_item118 i " +
                                                  "LEFT JOIN t_category118 c ON i.c_categoryid = c.c_categoryid " +
                                                  "WHERE c_itemid = @id", conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@id", id);

            using var reader = command.ExecuteReader();

            var record = new ItemModel();

            if (reader.Read())
            {
                _httpContextAccessor.HttpContext.Session.SetString("c_itemid", reader["c_itemid"].ToString());
                record.c_itemname = reader["c_itemname"].ToString();
                record.c_itemid = Convert.ToInt32(reader["c_itemid"]);
                record.c_itemcost = Convert.ToInt32(reader["c_itemcost"]);
                record.c_availablestock = Convert.ToInt32(reader["c_availablestock"]);


            }
            conn.Close();
            return record;
        }

        public void paymentinsert(ItemModel p)
        {
            var c_id = _httpContextAccessor.HttpContext.Session.GetString("c_id");
            var c_itemid = _httpContextAccessor.HttpContext.Session.GetString("c_itemid");
            try
            {
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO public.t_payment118 ( c_itemname, c_itemcost, c_qty,c_totalcost,c_id) VALUES (@c_itemname, @c_itemcost, @c_qty,@c_totalcost,@c_id)", conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@c_itemname", p.c_itemname);
                cmd.Parameters.AddWithValue("@c_itemcost", p.c_itemcost);
                cmd.Parameters.AddWithValue("@c_qty", p.c_qty);
                // cmd.Parameters.AddWithValue("@c_totalcost", Convert.ToInt32(p.c_totalcost));
                cmd.Parameters.Add("@c_totalcost", NpgsqlDbType.Numeric).Value = p.c_totalcost;
                cmd.Parameters.AddWithValue("@c_id",Convert.ToInt32(c_id));
                cmd.ExecuteNonQuery();
                conn.Close();


                    conn.Open();
                 using (var decreaseStockCmd = new NpgsqlCommand("UPDATE public.t_item118 SET c_availablestock = c_availablestock - @c_qty WHERE c_itemid = @c_itemid", conn))
                        {
                            decreaseStockCmd.Parameters.AddWithValue("@c_qty", p.c_qty);
                            decreaseStockCmd.Parameters.AddWithValue("@c_itemid", Convert.ToInt32(c_itemid));
                            decreaseStockCmd.ExecuteNonQuery();
                        }
                conn.Close();


            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
            }
            // finally
            // {
            //     conn.Close();
            // }
        }

       

        public List<ItemModel> FetchUserItems()
        {
            var items = new List<ItemModel>();
            var c_id = _httpContextAccessor.HttpContext.Session.GetString("c_id");
            var c_itemid = _httpContextAccessor.HttpContext.Session.GetString("c_itemid");
            try
            {
                conn.Open();
                using var cmd = new NpgsqlCommand("select * from t_payment118 where c_id = @c_id", conn);
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@c_id", Convert.ToInt32(c_id));
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    var item = new ItemModel
                    {
                        c_purchaseid = Convert.ToInt32(reader["c_purchaseid"]),
                        c_id = Convert.ToInt32(reader["c_id"]),
                        c_itemname = reader["c_itemname"].ToString(),
                        // c_itemimage = reader["c_itemimage"].ToString(),
                        c_itemcost = Convert.ToInt32(reader["c_itemcost"]),
                        c_qty = Convert.ToInt32(reader["c_qty"]),
                        c_totalcost = Convert.ToInt32(reader["c_totalcost"]),
                        // Add category name fetched from the join
                    };
                    items.Add(item);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error: {e.Message}");
            }
            finally
            {
                conn.Close();
            }
            return items;
        }
        public List<ItemModel> FetchPurchaseData()
        {
            var items = new List<ItemModel>();
            try
            {
                conn.Open();
                using var cmd = new NpgsqlCommand("SELECT t_payment118.*, t_auth118.c_name AS customer_name FROM t_payment118 INNER JOIN t_auth118 ON t_payment118.c_id = t_auth118.c_id", conn);
                cmd.CommandType = CommandType.Text;
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    var item = new ItemModel
                    {
                        c_purchaseid = Convert.ToInt32(reader["c_purchaseid"]),
                        c_itemname = reader["c_itemname"].ToString(),
                        // c_itemimage = reader["c_itemimage"].ToString(),
                        c_itemcost = Convert.ToInt32(reader["c_itemcost"]),
                        c_qty = Convert.ToInt32(reader["c_qty"]),
                        c_totalcost = Convert.ToInt32(reader["c_totalcost"]),
                        // c_id= Convert.ToInt32(reader["c_id"]),
                        c_name = reader["customer_name"].ToString(),
                    };
                    items.Add(item);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Error: {e.Message}");
            }
            finally
            {
                conn.Close();
            }
            return items;
        }

    }
}