using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC.Models
{
    public class EmpModel
    {
        public int c_eid { get; set; }
        public string? c_ename { get; set; } 
        public DateTime c_date { get; set; }
        public double c_salary { get; set; }
        public int c_designation { get; set; }
        public string? c_gender { get; set; } 
        public int c_did { get; set; }
        public string? c_dname { get; set; } 
        public double c_da { get; set; }
        public double c_hra { get; set; }
        public double c_taxable { get; set; }
        public double c_tax { get; set; }
        public double c_takehome { get; set; }

    }
}