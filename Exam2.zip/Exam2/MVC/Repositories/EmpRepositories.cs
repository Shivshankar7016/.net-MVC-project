using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MVC.Models;
using Npgsql;

namespace MVC.Repositories
{
    public class EmpRepositories : CommonRepositories, IEmpRepositories
    {
        private readonly IHttpContextAccessor _httpContextAccessor;

        public EmpRepositories(IHttpContextAccessor httpContextAccessor) {
            _httpContextAccessor = httpContextAccessor;
        }
        public List<EmpModel> GetAllDesignation()
        {
            List<EmpModel> empList = new List<EmpModel>();

            conn.Open();

            using (var cmd = new NpgsqlCommand("SELECT c_did, c_dname FROM t_designation118;", conn))
            using (var dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    var emp = new EmpModel
                    {
                        c_did = Convert.ToInt32(dr["c_did"]),
                        c_dname = dr["c_dname"].ToString()
                    };
                    empList.Add(emp);
                }
            }

            conn.Close();

            return empList;
        }

        public void InsertEmp(EmpModel emp)
        {
            conn.Open();

            using var command = new NpgsqlCommand("Insert into t_emp118(c_ename, c_date, c_salary, c_designation, c_gender) Values(@c_ename, @c_date, @c_salary, @c_designation, @c_gender)", conn);
            command.CommandType = CommandType.Text;

            command.Parameters.AddWithValue("@c_ename", emp.c_ename);
            command.Parameters.AddWithValue("@c_date", emp.c_date);
            command.Parameters.AddWithValue("@c_salary", Convert.ToDouble(emp.c_salary));
            command.Parameters.AddWithValue("@c_designation", Convert.ToInt32(emp.c_designation));
            command.Parameters.AddWithValue("@c_gender", emp.c_gender);

            command.ExecuteNonQuery();

            conn.Close();
        }

        public List<EmpModel> FetchAllEmpsForAdmin(EmpModel employee)
        {
            var records = new List<EmpModel>();
            conn.Open();

            // var c_lid = _httpContextAccessor.HttpContext.Session.GetString("c_lid");

            using var command = new NpgsqlCommand("select c_eid, c_ename, c_date, c_salary, c_designation, c_gender, c_dname from t_emp118 left join t_designation118 on t_emp118.c_designation = t_designation118.c_did where c_did != 0", conn);
            command.CommandType = CommandType.Text;

            using var reader = command.ExecuteReader();

            while (reader.Read())
            {
                var emp = new EmpModel
                {
                    c_eid = Convert.ToInt32(reader["c_eid"]),
                    c_ename = reader["c_ename"].ToString(),
                    c_date = Convert.ToDateTime(reader["c_date"]),
                    c_salary = Convert.ToDouble(reader["c_salary"]),
                    c_dname = reader["c_dname"].ToString(),
                    c_gender = reader["c_gender"].ToString()
                };
                records.Add(emp);
            }
            conn.Close();

            return records;
        }

        public EmpModel ShowEmp(int id)
        {
            conn.Open();

            using var command = new NpgsqlCommand("select c_eid, c_ename, c_date, c_salary, c_designation, c_gender, c_dname from t_emp118 left join t_designation118 on t_emp118.c_designation = t_designation118.c_did where c_eid = @id", conn);
            command.CommandType = CommandType.Text;
            command.Parameters.AddWithValue("@id", id);

            using var reader = command.ExecuteReader();

            var record = new EmpModel();

            if (reader.Read())
            {
                record.c_eid = Convert.ToInt32(reader["c_eid"]);
                record.c_ename = reader["c_ename"].ToString();
                record.c_dname = reader["c_dname"].ToString();
                record.c_salary = Convert.ToDouble(reader["c_salary"]);
                record.c_date = Convert.ToDateTime(reader["c_date"]);
                record.c_gender = reader["c_gender"].ToString();
                record.c_designation = Convert.ToInt32(reader["c_designation"]);
            }
            conn.Close();
            return record;
        }

        public bool UpdateEmp(int id, EmpModel updatedRecord)
        {
            try
            {
                conn.Open();

                using var command = new NpgsqlCommand("UPDATE t_emp118 SET c_ename = @c_ename, c_date = @c_date, c_salary = @c_salary, c_designation = @c_designation, c_gender = @c_gender WHERE c_eid = @id", conn);
                command.CommandType = CommandType.Text;

                command.Parameters.AddWithValue("@id", id);
                command.Parameters.AddWithValue("@c_ename", updatedRecord.c_ename);
                command.Parameters.AddWithValue("@c_date", updatedRecord.c_date);
                command.Parameters.AddWithValue("@c_salary", Convert.ToDouble(updatedRecord.c_salary));
                command.Parameters.AddWithValue("@c_designation", Convert.ToInt32(updatedRecord.c_designation));
                command.Parameters.AddWithValue("@c_gender", updatedRecord.c_gender);

                int rowsAffected = command.ExecuteNonQuery();

                return rowsAffected > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating record: " + ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool UpdatePayroll(int id, EmpModel updatedRecord)
        {
            try
            {
                conn.Open();

                using var command = new NpgsqlCommand("UPDATE t_emp118 SET c_da = @c_da, c_hra = @c_hra, c_taxable = @c_taxable, c_tax = @c_tax, c_takehome = @c_takehome WHERE c_eid = @id", conn);
                command.CommandType = CommandType.Text;

                command.Parameters.AddWithValue("@id", id);
                command.Parameters.AddWithValue("@c_da", updatedRecord.c_da);
                command.Parameters.AddWithValue("@c_hra", updatedRecord.c_hra);
                command.Parameters.AddWithValue("@c_taxable", updatedRecord.c_taxable);
                command.Parameters.AddWithValue("@c_tax", updatedRecord.c_tax);
                command.Parameters.AddWithValue("@c_takehome", updatedRecord.c_takehome);


                int rowsAffected = command.ExecuteNonQuery();

                return rowsAffected > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error updating record: " + ex.Message);
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public void DeleteEmp(int id)
        {
            conn.Open();

            using var command = new NpgsqlCommand("delete from t_emp118 where c_eid = @c_eid", conn);
            command.Parameters.AddWithValue("@c_eid", id);
            command.CommandType = CommandType.Text;

            command.ExecuteNonQuery();

            conn.Close();
        }
    }
}